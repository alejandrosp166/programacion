
public class Ejercicio6 {

	public static void main(String[] args) {
		int baseImp=40;
		
		System.out.print(baseImp+(baseImp*0.21));
	}

}
