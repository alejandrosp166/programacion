
public class Ejercicio5 {

	public static void main(String[] args) {
		/*Realiza un conversor de pesetas a euros. La cantidad en pesetas que se quiere convertir
deber� estar almacenada en una variable*/
		int ptas=1000;
		int euros = (ptas/166);
		
		System.out.print(euros);
	}

}
//1 -- 166
//x -- 670