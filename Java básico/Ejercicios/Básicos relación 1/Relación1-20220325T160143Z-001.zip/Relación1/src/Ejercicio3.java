
public class Ejercicio3 {

	public static void main(String[] args) {
	/*Crea las variables nombre, direccion y telefono y as�gnale los valores correspondientes.
Muestra los valores de esas variables por pantalla de tal forma que el resultado del programa
sea el mismo que en el ejercicio 2.*/
		String nombre ="Alejandro Seco Pineda";
		String tlfn="608456789";
		String direcc="C/Cueva del gato n�3 portal 7 4�D";
		System.out.println(nombre + " " + tlfn + " " + direcc);
	}

}
