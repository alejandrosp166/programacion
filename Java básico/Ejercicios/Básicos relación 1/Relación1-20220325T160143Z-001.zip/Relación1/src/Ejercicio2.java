
public class Ejercicio2 {

	public static void main(String[] args) {
		/*Crea la variable nombre y asignale tu nombre completo. A continuaci�n muestra su valor por pantalla.
*/
		String nombre= "Alejandro Seco Pineda";
		System.out.println(nombre);
	}

}
